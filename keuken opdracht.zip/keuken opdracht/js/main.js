// MODAL IN DE CONTACT PAGINA
/*
let modal = document.getElementById('model');
modal.classList.add('hidden');

function closeModal() {
    modal.classList.add('hidden');
    }

    document.querySelector('button').addEventListener('click', function(){
    let inputValueName = document.getElementById('data-naam').value;
    document.getElementById('p1').innerHTML = "Jouw Naam: " + inputValueName;

    let inputValueEmail = document.getElementById('data-email').value;
    document.getElementById('p2').innerHTML = "Jouw Email: " + inputValueEmail;

    let inputValueTel = document.getElementById('data-tel').value;
    document.getElementById('p3').innerHTML = "Jouw Tel: " + inputValueTel;

    let inputValueBericht = document.getElementById('data-bericht').value;
    document.getElementById('p4').innerHTML = inputValueBericht;
    
    modal.classList.remove('hidden');
})
*/


// MODAL FROM W3SCHOOLS
// Get the modal
let modal = document.getElementById('myModal');

// Get the button that opens the modal
let btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
let span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal
    btn.onclick = function() {

    let inputValueName = document.getElementById('data-naam').value;
    let inputValueEmail = document.getElementById('data-email').value;
    let inputValueTel = document.getElementById('data-tel').value;
    let inputValueBericht = document.getElementById('data-bericht').value;

    if (inputValueName === '' || inputValueEmail === '' || inputValueTel === '' || inputValueBericht === '') {
        
        modal.style.display = "none";
    } else {
    event.preventDefault();    
    modal.style.display = 'block';

    document.getElementById('p1').innerHTML = "Bedankt  voor het invullen van jouw gegevens. Wij hebben het volgende opgeslagen.";

    document.getElementById('p2').innerHTML = 'Naam: ' + inputValueName;

    document.getElementById('p3').innerHTML = 'Email: ' + inputValueEmail;

    document.getElementById('p4').innerHTML = 'Telefoonnummer: ' + inputValueTel;
    
    document.getElementById('p5').innerHTML = 'Bericht: ' + inputValueBericht;
}
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = 'none';
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}
