let contactName = document.getElementById('data-naam');
contactName.oninvalid = function (e) {
  e.target.setCustomValidity("");
  if (e.target.validity.valid == false) {
    if (e.target.value.length == 0) {
      e.target.setCustomValidity("Vul uw naam in.");
    } else if (e.target.value.length < 5) {
      e.target.setCustomValidity("Contact name must be at least 5 characters.");
    }
  }
};

let email = document.getElementById('data-email');
email.oninvalid = function (e) {
  e.target.setCustomValidity("");
  if (e.target.validity.valid == false) {
    if (e.target.value.length == 0) {
      e.target.setCustomValidity("Email is required.");
    } else {
      e.target.setCustomValidity("Please enter a valid email address.");
    }
  }
};


/*
// Onblur method op de naam inputfield
let idNaam = document.getElementById("data-naam");
idNaam.addEventListener("blur", function(){
    if (idNaam.value === '') {
        let message = document.getElementById('message');
        message.style.width = '80%';
        message.style.margin = '0 auto';
        message.style.border = '5px solid red';
        message.style.color = 'red';
        message.innerHTML = 'Vul jouw naam in';
    }else {
        message.style.display = 'none';
    }
});
*/

/*
function blurNaam() {
    let idNaam = document.getElementById("data-naam");
    if (idNaam.value === '') {
        let para = document.createElement("P");
        let t = document.createTextNode("Geen naam ingevuld.");
        para.appendChild(t);
        document.idNaam.appendChild(para);
    }
}
*/